package com.cg.service;

import java.util.List;

import javax.persistence.criteria.Order;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.repository.IDaoReturneditem;
import com.cg.repository.IDaoReturnstatus;

import com.cg.repository.IDaoTransaction;

import com.cg.bankservice.BankWebService;
import com.cg.bankservice.BankWebServiceService;
import com.cg.domain.JoinOrdersTransaction;
import com.cg.domain.Product;
import com.cg.domain.Returneditem;
import com.cg.domain.Returnstatus;
import com.cg.domain.Shipping;

import com.cg.repository.IDaoOrder;
import com.cg.repository.IDaoProduct;
import com.cg.repository.IDaoShipping;

@Service
public class ServiceClass {

	@Autowired
	public IDaoOrder idaoorder;
	@Autowired
	public IDaoProduct idaoproduct;

	@Autowired
	public IDaoReturneditem idaoreturneditem;
	@Autowired
	public IDaoReturnstatus idaoreturnstatus;

	@Autowired
	public IDaoShipping idaoshipping;
	@Autowired
	public IDaoTransaction idaotransaction;

	@Transactional
	public List<Returneditem> storeDetails() {

		List<Returneditem> ret_list = idaoreturneditem.findAll();

		return ret_list;

	}

	@Transactional
	public void setReturnedItems(String prodid) {

		Returneditem rti = new Returneditem();
		String[] s = prodid.split(",");
		rti.setOrderId(Long.parseLong(s[0]));
		rti.setUserId(s[1]);
		rti.setProductId(s[2]);
		rti.setProductName(s[3]);
		rti.setProductCost(Double.parseDouble(s[4]));
		rti.setTransactionId(Long.parseLong(s[5]));
		rti.setProductQuantity(Long.parseLong(s[6]));
		rti.setReturnStatus("Pending");
		rti.setReturnstatusId(Long.parseLong(s[8]));
		idaoreturneditem.saveAndFlush(rti);
	}

	@Transactional
	public void setReturnStatus(String prodid) {

		String[] s = prodid.split(",");

		Returnstatus o = idaoreturnstatus.findById(Long.parseLong(s[8]));

		List<Returnstatus> oList = idaoreturnstatus.findAll();
		for (Returnstatus ot : oList) {
			if (ot.getReturnStatus() == o.getReturnStatus()) {
				ot.setReturnStatus("Pending");
				idaoreturnstatus.save(ot);
				break;
			}
		}
	}

	@Transactional
	public void deleteProduct(String id, int quan) {
		Product p = idaoproduct.findOne(id);
		long amt = p.getProductStock() - quan;
		p.setProductStock(amt);
		idaoproduct.save(p);
	}

	@Transactional
	public void increaseProduct(String id, int quan) {
		Product p = idaoproduct.findOne(id);
		long amt = p.getProductStock() + quan;
		p.setProductStock(amt);
		idaoproduct.save(p);
	}

	public void setReturnApprove(long returnstatusId, String productId, long transactionId, double productCost) {

		idaoproduct.updateInventory(productId);

		BankWebServiceService b = new BankWebServiceService();

		BankWebService bs = b.getBankWebServicePort();

		bs.refund(transactionId, (float) productCost, "Product Refund");

		idaoreturneditem.setReturnedApprove(returnstatusId);

		idaoreturnstatus.setRStatusApprove(returnstatusId);

	}

	@Transactional
	public void setReturnReject(long returnstatusId) {

		idaoreturneditem.setReturnedReject(returnstatusId);

		idaoreturnstatus.setRStatusReject(returnstatusId);

	}

	@Transactional
	public JoinOrdersTransaction getdetails(long order_id) {
		// TODO Auto-generated method stub
		JoinOrdersTransaction jot = new JoinOrdersTransaction();
		Order order_detail = (Order) idaoorder.findByOrderId(order_id);
		jot.setOrders(order_detail);
		List<Shipping> ship = idaoshipping.findByOrder_id(order_id);
		List<com.cg.domain.Transaction> order_desc = idaotransaction.findByOrder_id(order_id);
		jot.setTransactions(order_desc);

		jot.setShipping(ship);

		return jot;
	}

	@Transactional
	public List<Returneditem> storeDetails1() {

		List<Returneditem> ret_list = idaoreturneditem.findAll();

		return ret_list;

	}

	@Transactional
	public List<com.cg.domain.Transaction> getOrder(String id) {
		List<com.cg.domain.Transaction> list = idaoorder.getBymerchantId(id);
		return list;
	}
}
