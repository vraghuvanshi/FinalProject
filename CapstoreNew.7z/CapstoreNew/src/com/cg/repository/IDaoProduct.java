package com.cg.repository;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;




import com.cg.domain.Product;


@Repository
public interface IDaoProduct extends JpaRepository<Product,String>{

	
	
	@Transactional
	 @Modifying
	 @Query("update Product p set p.productStock=p.productStock+1 where p.productId = ?1")
	 public void updateInventory(String productId);
	
	


}
