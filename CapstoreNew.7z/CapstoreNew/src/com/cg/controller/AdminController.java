package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.domain.Returneditem;
import com.cg.service.ServiceClass;



@Controller
@RequestMapping("/")
public class AdminController {

	@Autowired
	public ServiceClass sc;
	
	
	
	

	@RequestMapping(value="updateinventory")
	public String navigate(@RequestParam("id")String ID,@RequestParam("amt")String quan,@RequestParam("update")String control){
		if(control.equals("Reduce_stock")){
			sc.deleteProduct(ID,Integer.parseInt(quan));

			return "UpdateSuccessByAdmin";
		}
		else{
			sc.increaseProduct(ID,Integer.parseInt(quan));

			return "UpdateSuccessByAdmin";
		}
	}

	
	@RequestMapping(value = "adminreject")
	public String getReject(ModelMap map,
			@RequestParam("hidd1") int returnstatusId) {

		sc.setReturnReject(returnstatusId);

		List<Returneditem> l1 = sc.storeDetails();
		map.put("list1", l1);
		return "ReturnValidationByAdmin";

	}
	@RequestMapping(value = "adminreturn", method = RequestMethod.GET)
	public String returnUser(ModelMap map) {

		List<Returneditem> l1 = sc.storeDetails();
		map.put("list1", l1);
		return "ReturnValidationByAdmin";
	}
	

	
	

}
