package com.cg.domain;

public class RevenueTable {
	String firstquarter="First Quarter";
	String secondquarter="Second Quarter";
	String thirdquarter="Third Quarter";
	String fourthquarter="Fourth Quarter";
	double firstrevenue;
	double secondrevenue;
	double thirdrevenue;
	double fourthrevenue;
	double revenue;
	public double getRevenue() {
		return revenue;
	}
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	public double getFirstrevenue() {
		return firstrevenue;
	}
	public void setFirstrevenue(double firstrevenue) {
		this.firstrevenue = firstrevenue;
	}
	public double getSecondrevenue() {
		return secondrevenue;
	}
	public void setSecondrevenue(double secondrevenue) {
		this.secondrevenue = secondrevenue;
	}
	public double getThirdrevenue() {
		return thirdrevenue;
	}
	public void setThirdrevenue(double thirdrevenue) {
		this.thirdrevenue = thirdrevenue;
	}
	public double getFourthrevenue() {
		return fourthrevenue;
	}
	public void setFourthrevenue(double fourthrevenue) {
		this.fourthrevenue = fourthrevenue;
	}
	
	


}
